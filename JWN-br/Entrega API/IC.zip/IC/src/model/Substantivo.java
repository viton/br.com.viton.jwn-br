package model;


public class Substantivo extends ReferencedSynset{
	public Substantivo(){
		setType(TipoSynset.SUBSTANTIVO);
	}
}
