package model;


public class Verbo extends ReferencedSynset{
	public Verbo(){
		setType(TipoSynset.VERBO);
	}
}
