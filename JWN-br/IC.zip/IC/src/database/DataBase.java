package database;

import java.util.ArrayList;
import java.util.List;

import model.Synset;

public class DataBase {
	private static List<Synset> synsets = new ArrayList<Synset>();
	
	public static void addSynset(Synset s){
		synsets.add(s);
	}
	public static List<Synset> getSynsets(String s){
		List<Synset> ss = new ArrayList<Synset>();
		for(int i=0; i<synsets.size(); i++){
			if(synsets.get(i).getWordForm().equalsIgnoreCase(s))
				ss.add(synsets.get(i));
		}
		
		if(ss.size() == 0){
			return null;
		}
		return ss;
	}
	
	public static boolean exists(String s){
		for(int i=0; i<synsets.size(); i++){
			if(synsets.get(i).getWordForm().equalsIgnoreCase(s))
				return true;
		}
		return false;
	}
	
	public static List<Synset> getSynsetsByReference(int reference){
		List<Synset> ss = new ArrayList<Synset>();
		for(int i=0; i<synsets.size(); i++){
			for(int k=0; k<synsets.get(i).getSynonymousPointer().size(); k++){
					if(synsets.get(i).getSynonymousPointer().get(k) == reference)
						ss.add(synsets.get(i));
			}
		}
		
		if(ss.size() == 0) return null;
		else return ss;
	}
	public static int tamanhoBase(){
		return synsets.size();
	}
	public static List<Synset> getSynsets(){
		return synsets;
	}
}
