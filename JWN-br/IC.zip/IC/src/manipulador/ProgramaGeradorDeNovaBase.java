package manipulador;

import java.util.ArrayList;
import java.util.List;

import model.Synset;
	
import database.DataBase;

public class ProgramaGeradorDeNovaBase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ControleES c = new ControleES();
		//c.leitorBaseTep("C:\\Users\\vitormo\\Desktop\\novaBase.txt", 
			//			"C:\\Users\\vitormo\\Desktop\\base_tep2.txt");
		c.geraWordNetBr("C:\\Users\\vitormo\\Desktop\\novaBase.txt");
		System.out.println(DataBase.tamanhoBase());
		List<Synset> list = DataBase.getSynsets("mapa");
		Synset s ;
		List<Synset> aux;
		for(int i=0; i<list.size(); i++){
			s = list.get(i);
			aux = s.getSinonimos();
			for(int j=0; j<aux.size(); j++){
				System.out.println(aux.get(j));
			}
			System.out.println();
			System.out.println();
		}
	}

}
