package manipulador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import database.DataBase;

import model.Adjetivo;
import model.Adverbio;
import model.Substantivo;
import model.Synset;
import model.Verbo;

public class ControleES {
	/*
	 * Metodos que Escrevem no logFile
	 */
	
	public void geraNovaBase(List<String> conteudo, String arquivoSaida){
		try {
			BufferedWriter b = new BufferedWriter(new FileWriter(arquivoSaida));
			for(int i=0; i<conteudo.size(); i++){
				b.write(conteudo.get(i));
				b.newLine();
			}
			b.close();
		} catch (IOException e) {
			System.out.println("Entrou na Exce��o");
		}
	}
	
	/*
	 ******************************************************
	 */
	
	/*
	 * Leitura das Prioridades 
	 */
	public void leitorBaseTep(String caminhoSaida, String caminhoLeitura){
		Scanner s = null;
		Scanner l = null;
		StringBuffer str;
		String aux;
		List<String> novaBase = new ArrayList<String>();
		try {	
			s = new Scanner(new BufferedReader(new FileReader(caminhoLeitura)));
			s.useDelimiter("\n");
			while(s.hasNext()){
				str = new StringBuffer();
				l = new Scanner(s.next());
				while(l.hasNext()){
					aux = l.next();
					for(int i=0; i<aux.length(); i++){
						if((aux.charAt(i) == '[')||(aux.charAt(i) == ']')||(aux.charAt(i) == '{')||(aux.charAt(i) == '}') || (aux.charAt(i) == '.')
								|| (aux.charAt(i) == ',') || (aux.charAt(i) == '>')){
							
						}
						else if((aux.charAt(i) == '<')){
							str.append('.');
						}
						else{
							str.append(aux.charAt(i));
						}
						
					}
					str.append(" ");
				}
				novaBase.add(new String(str));
			}
			geraNovaBase(novaBase, caminhoSaida);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void geraWordNetBr(String caminho){
		Scanner s = null;
		Scanner l = null;
		String aux;
		Synset synset;
		int referenciaSinonimo;
		int referenciaAntonimo;
		List<Synset> adicionar;
		try {	
			s = new Scanner(new BufferedReader(new FileReader(caminho)));
			s.useDelimiter("\n");
			while(s.hasNext()){
				l = new Scanner(s.next());
				adicionar = new ArrayList<Synset>(); 
				referenciaSinonimo = Integer.parseInt(l.next());
				referenciaAntonimo = 0;
				while(l.hasNext()){
					aux = l.next();
					if(aux.charAt(0) == 'V'){
						while(l.hasNext()){
							aux = l.next();
							if(aux.charAt(0) == '.'){
								referenciaAntonimo = (Integer.parseInt(aux.substring(1)));
							}else{
								synset = new Verbo();
								synset.setSynonymousPointer(referenciaSinonimo);
								synset.setWordForm(aux);
								adicionar.add(synset);
							}
								
						}
						for(int i=0; i<adicionar.size(); i++){
							((Verbo) adicionar.get(i)).setAntonymousPointer(referenciaAntonimo);
							DataBase.addSynset(adicionar.get(i));
						}
					}else if(aux.charAt(2) == 'v'){
						while(l.hasNext()){
							aux = l.next();
							if(aux.charAt(0) == '.'){
								referenciaAntonimo = (Integer.parseInt(aux.substring(1)));
							}else{
								synset = new Adverbio();
								synset.setSynonymousPointer(referenciaSinonimo);
								synset.setWordForm(aux);
								adicionar.add(synset);
							}
								
						}
						for(int i=0; i<adicionar.size(); i++){
							((Adverbio) adicionar.get(i)).setAntonymousPointer(referenciaAntonimo);
							DataBase.addSynset(adicionar.get(i));
						}
					}else if(aux.charAt(0) == 'S'){
						while(l.hasNext()){
							aux = l.next();
							if(aux.charAt(0) == '.'){
								referenciaAntonimo = (Integer.parseInt(aux.substring(1)));
							}else{
								synset = new Substantivo();
								synset.setSynonymousPointer(referenciaSinonimo);
								synset.setWordForm(aux);
								adicionar.add(synset);
							}
								
						}
						for(int i=0; i<adicionar.size(); i++){
							((Substantivo) adicionar.get(i)).setAntonymousPointer(referenciaAntonimo);
							DataBase.addSynset(adicionar.get(i));
						}
					}else if(aux.charAt(2) == 'j'){
						while(l.hasNext()){
							aux = l.next();
							if(aux.charAt(0) == '.'){
								referenciaAntonimo = (Integer.parseInt(aux.substring(1)));
							}else{
								synset = new Adjetivo();
								synset.setSynonymousPointer(referenciaSinonimo);
								synset.setWordForm(aux);
								adicionar.add(synset);
							}
								
						}
						for(int i=0; i<adicionar.size(); i++){
							((Adjetivo) adicionar.get(i)).setAntonymousPointer(referenciaAntonimo);
							DataBase.addSynset(adicionar.get(i));
						}
					}
					
					
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
