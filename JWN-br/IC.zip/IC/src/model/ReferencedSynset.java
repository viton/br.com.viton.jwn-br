package model;

import java.util.ArrayList;
import java.util.List;

import database.DataBase;

public class ReferencedSynset implements Synset{
	private String type;
	private List<Integer> synonymousReference = new ArrayList<Integer>();
	private List<Integer> antonymReference = new ArrayList<Integer>();
	private String wordForm;
	@Override
	public List<Synset> getSinonimos() {
		List<Synset> ss = new ArrayList<Synset>();
		for(int i=0; i<synonymousReference.size(); i++)
			ss.addAll(DataBase.getSynsetsByReference(synonymousReference.get(i)));
		return ss;
	}
	@Override
	public List<Synset> getAntonimos() {
		List<Synset> ss = new ArrayList<Synset>();
		for(int i=0; i<antonymReference.size(); i++)
			ss.addAll(DataBase.getSynsetsByReference(antonymReference.get(i)));
		return ss;
	}
	public String getWordForm() {
		return wordForm;
	}
	@Override
	public List<Integer> getSynonymousPointer() {
		return synonymousReference;
	}
	@Override
	public List<Integer> getAntonymPointer() {
		return antonymReference;
	}
	
	public String toString(){
		return (type + " " + wordForm + " " + synonymousReference + " " + antonymReference);
	} 
	public void setType(String type){
		this.type = type;
	}
	@Override
	public void setSynonymousPointer(int pointer) {
		synonymousReference.add(pointer);		
	}
	@Override
	public void setAntonymousPointer(int pointer) {
		antonymReference.add(pointer);		
	}
	@Override
	public String getType() {
		return this.type;
	}
	@Override
	public void setWordForm(String s) {
		wordForm = s;
	}
}
