package model;


public class Adjetivo extends ReferencedSynset{
	public Adjetivo(){
		setType(TipoSynset.ADJETIVO);
	}
	
}
