package model;


public class Adverbio extends ReferencedSynset{
	public Adverbio(){
		setType(TipoSynset.ADVERBIO);
	}
}
