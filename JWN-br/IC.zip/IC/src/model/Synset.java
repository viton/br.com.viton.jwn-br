package model;

import java.util.List;

public interface Synset {
	public String getWordForm ();
	public void setWordForm (String s);
	public List<Synset> getSinonimos();
	public List<Synset> getAntonimos();
	public List<Integer> getSynonymousPointer();
	public void setSynonymousPointer(int pointer);
	public List<Integer> getAntonymPointer();
	public void setAntonymousPointer(int pointer);
	public String toString();
	public String getType();
}
