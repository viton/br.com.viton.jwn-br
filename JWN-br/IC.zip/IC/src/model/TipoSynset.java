package model;

public class TipoSynset {
	public static final String VERBO = "VERBO";
	public static final String SUBSTANTIVO = "SUBSTANTIVO";
	public static final String ADJETIVO = "ADJETIVO";
	public static final String ADVERBIO = "ADVERBIO";
}
